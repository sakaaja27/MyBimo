<?php 
include 'koneksi.php';
$email = $_POST['email'];
$password = $_POST['password'];

$query = "SELECT * FROM users WHERE  email = '".$email."' AND password = '".md5($password)."'";
$msql = mysqli_query($connect, $query);
$result = mysqli_num_rows($msql);

if (!empty($email) && !empty($password)){
    if ($result > 0) {
        echo "Login Berhasil";
    }else{
        echo "Email atau Password Salah";
    }
}else{  
    echo "Data Tidak Boleh Kosong";
}
?>